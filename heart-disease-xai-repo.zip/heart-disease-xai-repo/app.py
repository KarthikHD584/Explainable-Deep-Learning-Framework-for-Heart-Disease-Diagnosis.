"""Streamlit app: explainable heart disease prediction from images (EfficientNetB0 + Grad-CAM)."""
import json
from pathlib import Path

import matplotlib
import numpy as np
import streamlit as st
from PIL import Image

matplotlib.use("Agg")

BASE_DIR = Path(__file__).parent
MODEL_PATH = BASE_DIR / "model" / "final_model.keras"
CLASSES_PATH = BASE_DIR / "model" / "class_names.json"
METRICS_PATH = BASE_DIR / "model" / "metrics.json"
ASSETS_DIR = BASE_DIR / "assets"
IMG_SIZE = (224, 224)

st.set_page_config(page_title="Explainable Heart Disease Diagnosis", page_icon="🫀", layout="wide")


@st.cache_resource(show_spinner="Loading model (first run only)...")
def load_model_and_parts():
    import tensorflow as tf

    model = tf.keras.models.load_model(MODEL_PATH, compile=False)
    base = next(l for l in model.layers if l.name.startswith("efficientnet"))
    last_conv = next(
        l.name for l in reversed(base.layers) if isinstance(l, tf.keras.layers.Conv2D)
    )
    # Nested backbone: tap the last conv layer inside it, then apply the head manually.
    feature_model = tf.keras.Model(
        base.inputs, [base.get_layer(last_conv).output, base.output]
    )
    head_layers = model.layers[model.layers.index(base) + 1:]
    return feature_model, head_layers


def predict_with_gradcam(image: Image.Image, threshold: float):
    import tensorflow as tf

    feature_model, head_layers = load_model_and_parts()
    arr = np.asarray(image.convert("RGB").resize(IMG_SIZE), dtype=np.float32)
    batch = tf.expand_dims(arr, 0)  # pixel values 0-255; EfficientNet rescales internally

    with tf.GradientTape() as tape:
        conv_out, x = feature_model(batch)
        for layer in head_layers:
            x = layer(x)
        p = x[:, 0]
        # Explain the predicted class (p if positive, 1 - p if negative)
        target = tf.where(p >= threshold, p, 1.0 - p)
    grads = tape.gradient(target, conv_out)
    weights = tf.reduce_mean(grads, axis=(0, 1, 2))
    cam = tf.nn.relu(tf.reduce_sum(conv_out[0] * weights, axis=-1))
    cam = cam / (tf.reduce_max(cam) + 1e-8)
    return float(p.numpy()[0]), cam.numpy()


def overlay_heatmap(image: Image.Image, cam: np.ndarray, alpha: float) -> Image.Image:
    img = image.convert("RGB")
    cam_img = Image.fromarray(np.uint8(255 * cam)).resize(img.size, Image.BILINEAR)
    heat = matplotlib.colormaps["jet"](np.asarray(cam_img) / 255.0)[..., :3] * 255
    blended = (1 - alpha) * np.asarray(img, dtype=np.float32) + alpha * heat
    return Image.fromarray(np.clip(blended, 0, 255).astype("uint8"))


# ----------------------------- UI -----------------------------
st.title("🫀 Explainable Deep Learning for Heart Disease Diagnosis")
st.warning(
    "Educational/research prototype. **Not a medical device** and not for clinical "
    "decisions. Always consult a qualified clinician."
)

if not MODEL_PATH.exists() or not CLASSES_PATH.exists():
    st.error(
        "Model files not found. Train the model with the Colab notebook, then place "
        "`final_model.keras` and `class_names.json` in the `model/` folder of this repo."
    )
    st.stop()

class_names = json.loads(CLASSES_PATH.read_text())
positive_class = class_names[1]

with st.sidebar:
    st.header("Settings")
    threshold = st.slider(
        f"Decision threshold for '{positive_class}'", 0.05, 0.95, 0.50, 0.05,
        help="The model outputs P(positive class). Lower the threshold to catch more positives "
             "(higher recall, more false alarms).",
    )
    alpha = st.slider("Heatmap opacity", 0.1, 0.9, 0.4, 0.05)
    st.caption(f"Class mapping: 0 = {class_names[0]}, 1 = {positive_class}")
    st.caption("Heatmap = Grad-CAM for the predicted class.")

uploaded = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg", "bmp"])

if uploaded is not None:
    image = Image.open(uploaded)
    with st.spinner("Running model..."):
        prob, cam = predict_with_gradcam(image, threshold)

    pred_idx = int(prob >= threshold)
    pred_label = class_names[pred_idx]
    confidence = prob if pred_idx == 1 else 1 - prob

    c1, c2, c3 = st.columns(3)
    c1.metric("Prediction", pred_label)
    c2.metric("Confidence", f"{confidence:.1%}")
    c3.metric(f"P({positive_class})", f"{prob:.1%}")

    left, right = st.columns(2)
    left.image(image.convert("RGB"), caption="Input image", use_container_width=True)
    right.image(
        overlay_heatmap(image, cam, alpha),
        caption="Grad-CAM: regions that most influenced this prediction",
        use_container_width=True,
    )
    st.caption(
        "Warm colours = stronger influence. A heatmap shows what the model used, "
        "not that it is clinically correct; check that it focuses on plausible regions."
    )
else:
    st.info("Upload an image to get a prediction and explanation.")

with st.expander("Model performance (held-out test set)"):
    if METRICS_PATH.exists():
        m = json.loads(METRICS_PATH.read_text())
        cols = st.columns(5)
        for col, key in zip(cols, ["accuracy", "precision", "recall", "f1", "roc_auc"]):
            col.metric(key.replace("_", " ").upper(), f"{m[key]:.3f}")
        st.caption(f"Test images: {m['n_test']} | positive class: {m['positive_class']}")
    else:
        st.write("Add `model/metrics.json` (from the notebook) to show metrics here.")
    for fname in ["confusion_matrix.png", "roc_curve.png", "gradcam_grid.png"]:
        if (ASSETS_DIR / fname).exists():
            st.image(str(ASSETS_DIR / fname), caption=fname, use_container_width=True)
